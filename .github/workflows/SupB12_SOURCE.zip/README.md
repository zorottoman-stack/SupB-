# SupB¹²

**Remember. Plan. Do.**

SupB¹² is a digital agenda / personal organization app concept.  
Remon is the friendly robotic salmon AI assistant.

## Design lock

- Logo: rounded calendar/clock + orange sun accent
- Mascot: Remon, robotic salmon
- Style: modern soft-neomorphic, rounded, calm and professional
- Orange = Reminder
- Blue = Plan
- Green = Completed
- Purple = AI / Thinking
- White = Normal

## Current build

Version: 0.1.0

This first source package contains the Android/Jetpack Compose UI foundation and navigation.  
The next iterations can connect real persistence, notifications, calendar/project systems, and the scoped Remon AI layer.
