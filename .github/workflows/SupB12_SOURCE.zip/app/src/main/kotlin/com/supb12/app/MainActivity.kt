package com.supb12.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B2545)
private val Blue = Color(0xFF1688F8)
private val Cyan = Color(0xFF43C7F4)
private val Orange = Color(0xFFFF914D)
private val Green = Color(0xFF2CCB73)
private val Purple = Color(0xFF8B55F6)
private val Surface = Color(0xFFF4F8FF)

data class Task(val title: String, val time: String, val color: Color, val done: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SupB12App() }
    }
}

@Composable
fun SupB12App() {
    var selected by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Surface,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Surface,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf(
                        "Ana Sayfa" to Icons.Default.Home,
                        "Takvim" to Icons.Default.CalendarMonth,
                        "Görevler" to Icons.Default.CheckCircle,
                        "Projeler" to Icons.Default.Folder,
                        "Remon" to Icons.Default.SmartToy
                    )
                    items.forEachIndexed { index, (label, icon) ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(icon, null) },
                            label = { Text(label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                0 -> HomeScreen(Modifier.padding(padding))
                1 -> CalendarScreen(Modifier.padding(padding))
                2 -> TasksScreen(Modifier.padding(padding))
                3 -> ProjectsScreen(Modifier.padding(padding))
                else -> RemonScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun BrandLogo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp)
                .background(Color.White, RoundedCornerShape(15.dp))
                .shadow(5.dp, RoundedCornerShape(15.dp))
                .border(1.dp, Color(0xFFE1EBF8), RoundedCornerShape(15.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(35.dp)) {
                val stroke = 6.dp.toPx()
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(Blue, Cyan)),
                    topLeft = Offset(5f, 8f),
                    size = androidx.compose.ui.geometry.Size(size.width - 10f, size.height - 10f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(9.dp.toPx()),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
                drawLine(Navy, Offset(size.width/2, 18f), Offset(size.width/2, 26f), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                drawLine(Navy, Offset(size.width/2, 26f), Offset(size.width/2 + 6f, 26f), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(Orange, radius = 6.dp.toPx(), center = Offset(size.width - 6.dp.toPx(), 7.dp.toPx()))
                for (i in 0..7) {
                    val a = Math.toRadians(i * 45.0)
                    val r1 = 9.dp.toPx()
                    val r2 = 12.dp.toPx()
                    val c = Offset(size.width - 6.dp.toPx(), 7.dp.toPx())
                    drawLine(Orange, c + Offset(kotlin.math.cos(a).toFloat()*r1, kotlin.math.sin(a).toFloat()*r1),
                        c + Offset(kotlin.math.cos(a).toFloat()*r2, kotlin.math.sin(a).toFloat()*r2), 2.dp.toPx(), StrokeCap.Round)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Text("Sup", color = Navy, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("B¹²", color = Blue, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun RemonBadge(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(22.dp))
            .border(1.dp, Color(0xFFE4ECF7), RoundedCornerShape(22.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp)
                .background(Orange.copy(alpha = .16f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("🐟", fontSize = 25.sp)
        }
        Spacer(Modifier.width(9.dp))
        Column {
            Text("Remon", fontWeight = FontWeight.Bold, color = Navy)
            Text("B¹² • Dijital Asistan", fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    val tasks = listOf(
        Task("Raporu tamamla", "10:00 - 11:00", Orange),
        Task("Spor yap", "12:30 - 13:30", Blue),
        Task("Market alışverişi", "Bugün", Green, true),
        Task("Uygulama arayüzünü incele", "16:00 - 17:00", Purple)
    )

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BrandLogo()
                RemonBadge()
            }
        }
        item {
            Text("Merhaba 👋", fontSize = 15.sp, color = Color.Gray)
            Text("Bugünün planı", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
            Text("İşlerini erteleme, zamanını hatırla.", color = Color.Gray)
        }
        item { SummaryCard() }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("＋", "Görev", Orange)
                QuickAction("▣", "Takvim", Blue)
                QuickAction("✎", "Not", Purple)
                QuickAction("🐟", "Remon", Green)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Bugünkü Görevler", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Tümünü Gör", color = Blue, fontSize = 12.sp)
            }
        }
        items(tasks) { TaskCard(it) }
    }
}

@Composable
fun SummaryCard() {
    Row(
        Modifier.fillMaxWidth()
            .background(Color.White, RoundedCornerShape(26.dp))
            .shadow(6.dp, RoundedCornerShape(26.dp))
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(105.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                drawArc(Blue, -90f, 250f, false, style = Stroke(12.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Color(0xFFE8EEF7), -90f, 110f, false, style = Stroke(12.dp.toPx(), cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("3/6", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("tamamlandı", fontSize = 9.sp, color = Color.Gray)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusLine(Orange, "2", "Hatırlatma")
            StatusLine(Blue, "2", "Planlandı")
            StatusLine(Green, "1", "Tamamlandı")
            StatusLine(Color.LightGray, "1", "Kalan")
        }
    }
}

@Composable
fun StatusLine(color: Color, number: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(number, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
fun QuickAction(icon: String, title: String, color: Color) {
    Column(
        Modifier.weight(1f)
            .background(Color.White, RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFFE5ECF5), RoundedCornerShape(18.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 20.sp, color = color)
        Spacer(Modifier.height(4.dp))
        Text(title, fontSize = 11.sp, color = Navy)
    }
}

@Composable
fun TaskCard(task: Task) {
    Row(
        Modifier.fillMaxWidth()
            .background(Color.White, RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFFE5ECF5), RoundedCornerShape(18.dp))
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(5.dp).height(44.dp).background(task.color, RoundedCornerShape(5.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(task.title, fontWeight = FontWeight.SemiBold, color = Navy)
            Text(task.time, fontSize = 11.sp, color = Color.Gray)
        }
        if (task.done) {
            Icon(Icons.Default.CheckCircle, null, tint = Green)
        } else {
            Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
        }
    }
}

@Composable
fun CalendarScreen(modifier: Modifier) {
    PlaceholderScreen(modifier, "Takvim", "Gün • Hafta • Ay", Icons.Default.CalendarMonth,
        "Planlarını zaman çizelgesinde gör. Hatırlatmalar turuncu, planlar mavi, tamamlananlar yeşil.")
}

@Composable
fun TasksScreen(modifier: Modifier) {
    PlaceholderScreen(modifier, "Görevler", "Bugün • Yaklaşan • Tamamlanan", Icons.Default.CheckCircle,
        "Görevlerini oluştur, önceliklendir, planla ve tamamla.")
}

@Composable
fun ProjectsScreen(modifier: Modifier) {
    PlaceholderScreen(modifier, "Projeler", "Projelerini tek yerde takip et", Icons.Default.Folder,
        "Büyük hedeflerini proje, görev ve ilerleme adımlarına böl.")
}

@Composable
fun RemonScreen(modifier: Modifier) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Remon", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text("SupB¹²'nin dijital asistanı", color = Color.Gray)
        Box(
            Modifier.fillMaxWidth()
                .background(
                    Brush.linearGradient(listOf(Color.White, Color(0xFFEAF7FF))),
                    RoundedCornerShape(28.dp)
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("🐟  Merhaba! Ben Remon.", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text(
                    "Planlarını, görevlerini, projelerini, notlarını ve alışkanlıklarını SupB¹² içinde analiz etmene yardımcı olurum.",
                    color = Color.DarkGray
                )
                Text("Ben yalnızca SupB¹² hakkında yardımcı olurum.", color = Purple, fontWeight = FontWeight.SemiBold)
            }
        }
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Remon'a bir şey sor...") },
            trailingIcon = { Icon(Icons.Default.Send, null, tint = Blue) },
            shape = RoundedCornerShape(22.dp)
        )
    }
}

@Composable
fun PlaceholderScreen(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String
) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
                Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            }
        }
        Text(description, color = Color.Gray)
        repeat(4) { i ->
            Box(
                Modifier.fillMaxWidth()
                    .height(72.dp)
                    .background(Color.White, RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFFE5ECF5), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Text("${title} öğesi ${i + 1}", fontWeight = FontWeight.SemiBold, color = Navy)
            }
        }
    }
}
